using UnityEngine;

public class Asteroid : MonoBehaviour
{
    public enum Size { Large, Medium, Small }
    public Size size = Size.Large;

    public GameObject asteroidPrefab;
    public float speed = 2f;

    [Header("Звук")]
    public AudioClip explosionSound;

    private Vector2 direction;

    public int ScoreValue()
    {
        switch (size)
        {
            case Size.Large: return 20;
            case Size.Medium: return 50;
            case Size.Small: return 100;
            default: return 0;
        }
    }

    void Start()
    {
        direction = Random.insideUnitCircle.normalized;
        float scale = size == Size.Large ? 1.2f : size == Size.Medium ? 0.7f : 0.35f;
        transform.localScale = Vector3.one * scale;

        // Сделать астероид серым
        Color gray = new Color(0.5f, 0.5f, 0.5f, 1f);
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr != null)
        {
            sr.color = gray;
        }
        else
        {
            MeshRenderer mr = GetComponent<MeshRenderer>();
            if (mr != null)
            {
                mr.material.color = gray;
            }
        }
    }

    void Update()
    {
        transform.position += (Vector3)(direction * speed * Time.deltaTime);
        WrapAround();
    }

    void WrapAround()
    {
        Vector3 pos = transform.position;
        Vector3 vp = Camera.main.WorldToViewportPoint(pos);

        if (vp.x < 0) vp.x = 1;
        else if (vp.x > 1) vp.x = 0;

        if (vp.y < 0) vp.y = 1;
        else if (vp.y > 1) vp.y = 0;

        transform.position = Camera.main.ViewportToWorldPoint(vp);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Bullet"))
        {
            Split();
            GameManager.Instance.AddScore(ScoreValue());
            if (explosionSound != null)
            {
                AudioSource.PlayClipAtPoint(explosionSound, transform.position);
            }
            Destroy(gameObject);
        }

        if (other.CompareTag("Player"))
        {
            GameManager.Instance.LoseLife();
            Destroy(gameObject);
        }
    }

    void Split()
    {
        if (size == Size.Small) return;

        Size nextSize = size == Size.Large ? Size.Medium : Size.Small;

        for (int i = 0; i < 2; i++)
        {
            GameObject child = Instantiate(asteroidPrefab, transform.position, Quaternion.identity);
            Asteroid a = child.GetComponent<Asteroid>();
            a.size = nextSize;
            a.asteroidPrefab = asteroidPrefab;
            a.speed = speed + 0.5f;
            a.explosionSound = explosionSound;
        }
    }
}