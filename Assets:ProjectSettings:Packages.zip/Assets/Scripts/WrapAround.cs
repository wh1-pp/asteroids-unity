using UnityEngine;

public class WrapAround : MonoBehaviour
{
    void Update()
    {
        Vector3 pos = transform.position;
        Vector3 vp = Camera.main.WorldToViewportPoint(pos);

        if (vp.x < 0) vp.x = 1;
        else if (vp.x > 1) vp.x = 0;

        if (vp.y < 0) vp.y = 1;
        else if (vp.y > 1) vp.y = 0;

        transform.position = Camera.main.ViewportToWorldPoint(vp);
    }
}
