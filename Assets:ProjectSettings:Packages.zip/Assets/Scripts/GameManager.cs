using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("UI")]
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI livesText;
    public GameObject gameOverPanel;

    [Header("Звук")]
    public AudioClip gameOverSound;
    private AudioSource audioSource;

    [Header("Астероиды")]
    public GameObject asteroidPrefab;
    public int asteroidsPerWave = 4;

    private int score = 0;
    private int lives = 3;
    private int wave = 1;
    private bool isGameOver = false;

    void Awake()
    {
        Instance = this;
        audioSource = GetComponent<AudioSource>();
    }

    void Start()
    {
        gameOverPanel.SetActive(false);
        SpawnWave();
        UpdateUI();
    }

    void Update()
    {
        if (isGameOver && Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        // Следующая волна если все астероиды уничтожены
        if (!isGameOver && FindObjectsByType<Asteroid>(FindObjectsSortMode.None).Length == 0)
        {
            wave++;
            asteroidsPerWave++;
            SpawnWave();
        }
    }

    void SpawnWave()
    {
        for (int i = 0; i < asteroidsPerWave; i++)
        {
            Vector3 spawnPos = GetRandomEdgePosition();
            GameObject a = Instantiate(asteroidPrefab, spawnPos, Quaternion.identity);
            a.GetComponent<Asteroid>().asteroidPrefab = asteroidPrefab;
        }
    }

    Vector3 GetRandomEdgePosition()
    {
        float x = Random.value < 0.5f ? 0f : 1f;
        float y = Random.value;
        if (Random.value < 0.5f) { float t = x; x = y; y = t; }
        Vector3 vp = new Vector3(x, y, 10f);
        return Camera.main.ViewportToWorldPoint(vp);
    }

    public void AddScore(int amount)
    {
        score += amount;
        UpdateUI();
    }

    public void LoseLife()
    {
        if (isGameOver) return;
        lives--;
        UpdateUI();

        if (lives <= 0)
        {
            GameOver();
        }
        else
        {
            // Возрождение игрока в центре
            GameObject player = GameObject.FindWithTag("Player");
            if (player != null)
            {
                player.transform.position = Vector3.zero;
                player.GetComponent<Rigidbody2D>().linearVelocity = Vector2.zero;
            }
        }
    }

    void GameOver()
    {
        isGameOver = true;
        gameOverPanel.SetActive(true);

        if (audioSource != null && gameOverSound != null)
        {
            audioSource.PlayOneShot(gameOverSound);
        }
    }

    void UpdateUI()
    {
        if (scoreText) scoreText.text = "Score: " + score;
        if (livesText) livesText.text = "Lives: " + lives;
    }
}