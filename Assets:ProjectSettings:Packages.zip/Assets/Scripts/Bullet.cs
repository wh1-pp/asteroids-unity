using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float lifetime = 2.5f;

    void Start()
    {
        Destroy(gameObject, lifetime);
    }

    void Update()
    {
        WrapAround();
    }

    void WrapAround()
    {
        Vector3 pos = transform.position;
        Vector3 vp = Camera.main.WorldToViewportPoint(pos);

        if (vp.x < 0) vp.x = 1;
        else if (vp.x > 1) vp.x = 0;

        if (vp.y < 0) vp.y = 1;
        else if (vp.y > 1) vp.y = 0;

        transform.position = Camera.main.ViewportToWorldPoint(vp);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Asteroid"))
        {
            Destroy(gameObject);
        }
    }
}
