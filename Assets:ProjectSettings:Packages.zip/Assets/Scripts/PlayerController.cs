using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Движение")]
    public float thrustForce = 5f;
    public float rotationSpeed = 200f;
    public float maxSpeed = 8f;

    [Header("Стрельба")]
    public GameObject bulletPrefab;
    public float bulletSpeed = 10f;
    public float fireRate = 0.3f;

    [Header("Звук")]
    public AudioClip shootSound;

    private Rigidbody2D rb;
    private AudioSource audioSource;
    private float nextFireTime;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        // Вращение
        float rotate = Input.GetAxis("Horizontal");
        transform.Rotate(0, 0, -rotate * rotationSpeed * Time.deltaTime);

        // Ускорение
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
        {
            rb.AddForce(transform.up * thrustForce);
        }

        // Ограничение скорости
        if (rb.linearVelocity.magnitude > maxSpeed)
        {
            rb.linearVelocity = rb.linearVelocity.normalized * maxSpeed;
        }

        // Выстрел
        if (Input.GetKey(KeyCode.Space) && Time.time > nextFireTime)
        {
            Shoot();
            nextFireTime = Time.time + fireRate;
        }
    }

    void Shoot()
    {
        if (bulletPrefab == null) return;
        GameObject bullet = Instantiate(bulletPrefab, transform.position, transform.rotation);
        bullet.GetComponent<Rigidbody2D>().linearVelocity = transform.up * bulletSpeed;

        if (audioSource != null && shootSound != null)
        {
            audioSource.PlayOneShot(shootSound);
        }
    }
}